#include <cstdio>
int main()
{
#ifndef IGNORE_ONLINE_JUDGE
   freopen("input.txt", "rt", stdin);
   freopen("output.txt", "wt", stdout)
#endif
return 0;
}